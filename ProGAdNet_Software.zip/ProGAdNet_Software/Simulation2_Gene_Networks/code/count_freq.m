
function [x] = count_freq(x)

x = x~=0;